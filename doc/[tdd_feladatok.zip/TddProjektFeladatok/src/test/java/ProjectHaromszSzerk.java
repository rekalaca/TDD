import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/**
 * @author koviildi
 * @version 1.0
 */
public class ProjectHaromszSzerk {
    /**
     * Lehetséges bemeneti értékek:
     * háromszög oldalai  : 1 – 100
     * Ha hibás értéket adunk át paraméterként, akkor térjen vissza -1 értékkel
     * Kategóriák:
     * - negatív szám előfordulása
     * - nulla érték előfordulása
     * - bármelyik, vagy mindhárom érték nagyobb a maximumnál
     * - 3 jó érték, de nem szerkeszthető
     * - mindhárom jó érték, és szerkeszthető
     */
    @Test
    @DisplayName("Háromszög szerkeszthetőségének tesztelése")
    public void test_haromszogSzerk(){
        assertEquals(-1, szerk(-1,5,8));
        assertEquals(-1, szerk(-5,-7,-6));
        assertEquals(-1, szerk(5,0,7));
        assertEquals(-1, szerk(0,0,0));
        assertEquals(-1, szerk(150,190,800));
        assertEquals(-1, szerk(150,80,90));
        assertEquals(-1, szerk(10,15,80));
        assertEquals(-1, szerk(22,3,4));
        assertEquals(70, szerk(15,25,30));
    }

    /**
     * A háromszög szerkeszthetőségének feltételeit vizsgáló metódus.
     * @param a háromszög egyik oldalának hossza,
     * @param b a háromszög második oldalának hossza,
     * @param c a háromszög harmadik oldalának hossza.
     * @return -1 ha az értékek egyik eleme is az adott értékhatáron kívül esik,
     * vagy nem teljesül a két oldal összegének feltétele,
     * különben a Kerület eredményét adja vissza.
     */
    private int szerk(int a, int b, int c) {
        if (a < 1 || b < 1 || c < 1)
            return -1;
        if (a > 100 || b > 100 || c > 100)
            return -1;
        if (a+b<c || a+c<b || b+c<a)
            return -1;
        else
            return a+b+c;

    }
}



