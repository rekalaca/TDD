
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * @author rekalaca
 * @version 1.0
 */

public class TestTomegTeszt {
    /**
     * Lehetséges bemeneti értékek:
     * súly  : 19,5 – 635
     * magasság : 0,54 – 2,72
     * Ha hibás értéket adunk át paraméterként, akkor térjen vissza -1 értékkel
     * Kategóriák:
     * - minkettő negatív
     * - mindkettő nulla
     * - egyik nulla, másik negatív - 2 esetet jelent
     * - egyik nulla, másik nagyobb - 2 esetet jelent
     * - egyik jó, másik negatív - 2 esetet jelent
     * - egyik jó, másik 0 - 2 esetet jelent
     * - egyik jó, másik nagyobb - 2 esetet jelent
     * -egyik jó, másik kisebb - 2 esetet jelent
     * - mindkettő jó
     */
    @Test
    @DisplayName("Testtömeg-indexet meghatározó metódus tesztelése")
    public void tesztTomegIndex() {
        assertEquals(-1, testTomeg(0.5, 18));
        assertEquals(-1, testTomeg(3.0, 18));
        assertEquals(-1, testTomeg(3.0, 700));
        assertEquals(-1, testTomeg(0.5, 700));
        assertEquals(-1, testTomeg(0.5, 100));
        assertEquals(-1, testTomeg(1.8, 18));
        assertEquals(-1, testTomeg(1.8, 700));
        assertEquals(-1, testTomeg(3.5, 80));
        assertEquals(-1, testTomeg(0, 0));
        assertEquals(-1, testTomeg(0, -20));
        assertEquals(-1, testTomeg(-20, 0));
        assertEquals(-1, testTomeg(-1, -1));
        assertEquals(-1, testTomeg(1.8, 0));
        assertEquals(-1, testTomeg(0, 80));
        assertEquals(-1, testTomeg(-1, 100));
        assertEquals(-1, testTomeg(80, -1));
        assertEquals(25, testTomeg(2.0, 100));
        assertEquals(21.604938271604937, testTomeg(1.8, 70));
        assertEquals(26.8595041322314, testTomeg(2.2, 130));


    }

    /**
     * A testtömeg index kiszámítását végző metódus.
     * @param magassag A felnőtt ember testmagassága
     * @param suly A ferlnőtt ember testének tömege
     * @return -1, ha az értékpárok, vagy az értépárok egyik eleme az adott
     * értékhatáron kívül esik,
     * különben az eredményt adja vissza.
     */


    private double testTomeg(double magassag, double suly) {
        if (magassag < 0.54 || suly < 19.5)
            return -1;
        if (magassag > 2.72 || suly > 635)
            return -1;
        return suly / (magassag * magassag);
    }
}


