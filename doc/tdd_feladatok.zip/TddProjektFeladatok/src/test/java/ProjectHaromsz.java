import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/**
 * @author koviildi
 * @version 1.0
 */
public class ProjectHaromsz {
    @Test
    @DisplayName("Háromszög típus meghatározásának tesztelése")
    public void test_HaromszogTipus(){
        assertEquals("nem háromszög", haromszog(2,5,0));
        assertEquals("nem háromszög", haromszog(2,0,9));
        assertEquals("nem háromszög", haromszog(-1,5,8));
        assertEquals("nem háromszög", haromszog(-5,-7,-6));
        assertEquals("nem háromszög", haromszog(5,0,7));
        assertEquals("nem háromszög", haromszog(0,0,0));
        assertEquals("nem háromszög", haromszog(150,190,800));
        assertEquals("nem háromszög", haromszog(150,80,1190));
        assertEquals("nem háromszög", haromszog(-20,-20,-20));
        assertEquals("nem háromszög", haromszog(10,15,80));
        assertEquals("Általános háromszög", haromszog(15,25,30));
        assertEquals("Egyenlő szárú háromszög", haromszog(20,20,30));
        assertEquals("Egyenlő oldalú háromszög", haromszog(20,20,20));
    }

    /**
     * A háromszög típusának meghatározását végző metódus.
     * @param a háromszög egyik oldalának hossza,
     * @param b a háromszög második oldalának hossza,
     * @param c a háromszög harmadik oldalának hossza.
     * @return "nem háromszög" ha a háromszög két oldalának összege nem nagyobb mint
     * a harmadik oldal, vagy nulla, vagy negatív hosszúságú bármelyik oldal, különben
     * Általános, Egyenlő szárú vagy Egyenlő oldalú háromszög értékkel tér vissza.
     */
    private String haromszog(int a, int b, int c) {
        if (a+b<=c || a+c<=b || b+c<=a || a<=0 || b<=0 || c<=0)
            return "nem háromszög";
        if (a == b && b ==c)
            return "Egyenlő oldalú háromszög";
        if (a == b || a ==c)
            return "Egyenlő szárú háromszög";
        else
            return "Általános háromszög";

    }

}

